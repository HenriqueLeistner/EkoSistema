# 🌿 Sistema Web Ekobrazil - Dados de Clientes

## 📖 Sobre o Sistema

Sistema web completo para visualização e filtragem de dados de clientes da Ekobrazil. Desenvolvido em HTML, CSS e JavaScript puro, sem dependências externas.

### ✨ Características:
- 🔐 **Login obrigatório** com 5 usuários pré-configurados
- 📊 **359 clientes** com dados reais
- 🎯 **Filtros inteligentes** por tempo desde última compra
- 🌐 **100% web** - funciona em qualquer servidor
- 📱 **Responsivo** - desktop, tablet e mobile
- 🎨 **Tema Ekobrazil** com logo e cores oficiais

## 🚀 Como Usar

### Opção 1: Servidor Python (Recomendado)
```bash
# No terminal, dentro desta pasta:
python3 -m http.server 8000

# Depois acesse:
http://localhost:8000/login.html
```

### Opção 2: Servidor Node.js
```bash
# Instalar servidor simples:
npm install -g http-server

# Executar:
http-server -p 8000

# Acessar:
http://localhost:8000/login.html
```

### Opção 3: Qualquer Servidor Web
- Coloque todos os arquivos em um servidor web
- Acesse `login.html` pelo navegador

## 🔑 Credenciais de Acesso

| Usuário    | Senha            | Nível        |
|------------|------------------|--------------|
| `daniela`  | `eko@eko`        | Usuário      |
| `admin`    | `ekobrazil123`   | Administrador|
| `gerente`  | `verde2024`      | Gerente      |
| `vendas`   | `cliente123`     | Vendas       |
| `ekobrazil`| `inteligencia2024`| Master      |

## 📁 Arquivos do Sistema

```
sistema_web_ekobrazil/
├── index.html      # Página principal (dados dos clientes)
├── login.html      # Página de login
├── styles.css      # Estilos da página principal
├── login.css       # Estilos da página de login
├── script.js       # Funcionalidades dos dados
├── auth.js         # Sistema de autenticação
├── data.js         # Base de dados (359 clientes)
├── logo.png        # Logo da Ekobrazil
├── LOGIN_INFO.md   # Documentação detalhada do login
└── README.md       # Este arquivo
```

## 🎯 Funcionalidades

### Sistema de Login:
- ✅ Autenticação obrigatória
- ✅ Sessão de 8 horas
- ✅ Opção "Lembrar de mim"
- ✅ Proteção contra força bruta
- ✅ Design responsivo

### Visualização de Dados:
- 📊 Lista completa de 359 clientes
- 🔍 Busca por nome
- 📅 Filtro por tempo desde última compra:
  - Últimos 30 dias
  - 31-60 dias
  - 61-90 dias
  - Mais de 90 dias
- 📈 Métricas em tempo real
- 💾 Download da lista filtrada

## 🌐 Compatibilidade

### Navegadores Suportados:
- Chrome 60+
- Firefox 55+
- Safari 12+
- Edge 79+

### Sistemas Operacionais:
- Windows (7, 8, 10, 11)
- macOS (10.12+)
- Linux (Ubuntu, CentOS, etc.)

## 🔧 Configurações

### Alterar Credenciais:
Edite o arquivo `auth.js` na linha:
```javascript
this.users = {
    'daniela': 'eko@eko',
    // ... outros usuários
};
```

### Personalizar Tema:
Edite `styles.css` e `login.css` para alterar:
- Cores (#9BC53D, #7BA428)
- Logo (substitua logo.png)
- Textos e títulos

## 📱 Teste Rápido

1. **Execute o servidor:**
   ```bash
   python3 -m http.server 8000
   ```

2. **Acesse no navegador:**
   ```
   http://localhost:8000/login.html
   ```

3. **Faça login:**
   - Usuário: `daniela`
   - Senha: `eko@eko`

4. **Explore o sistema:**
   - Veja os 359 clientes
   - Teste os filtros
   - Use a busca
   - Baixe relatórios

## ⚠️ Importante

### Para Produção:
Este sistema é ideal para:
- ✅ Uso interno da empresa
- ✅ Demonstrações e apresentações
- ✅ Acesso local ou intranet
- ✅ Prototipagem rápida

Para uso público, considere:
- 🔒 Autenticação via servidor
- 🔐 HTTPS obrigatório
- 🛡️ Hash das senhas
- 📊 Logs de segurança

### Vantagens desta Versão:
- 🚀 **Zero dependências** - roda em qualquer lugar
- ⚡ **Rápido** - carregamento instantâneo
- 🔧 **Fácil de modificar** - código simples
- 📱 **Universal** - funciona em qualquer dispositivo
- 💾 **Portável** - apenas alguns arquivos

## 🆘 Suporte

### Problemas Comuns:

**"Não carrega os dados"**
- Verifique se está usando um servidor web
- Não abra direto do explorador de arquivos

**"Login não funciona"**
- Verifique as credenciais na tabela acima
- Limpe o cache do navegador

**"Página em branco"**
- Verifique se JavaScript está habilitado
- Abra o console (F12) para ver erros

---

**Sistema Web Ekobrazil** v1.0  
Inteligência Ecológica - Gestão de Clientes  
Desenvolvido com HTML5, CSS3 e JavaScript ES6